# WEMOS_Motor_Shield_Arduino_Library
Arduino library for the WEMOS Motor Shiled - a shield for D1 mini, i2c interface, based TB6612